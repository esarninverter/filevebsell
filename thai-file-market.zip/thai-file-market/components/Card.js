import Link from 'next/link'
import { COLORS, baht, imgUrl } from '@/lib/const'
export default function Card({ p }) {
  const first = [...(p.product_images || [])].sort((a, b) => a.position - b.position)[0]
  return (
    <Link href={`/p/${p.id}`} className="card">
      <div className="thumb" style={{ '--c': COLORS[p.title.length % COLORS.length] }}>
        {first ? <img src={imgUrl(first.path)} alt={p.title} /> : <span className="ext">{p.file_type}</span>}
        <span className="badge">{p.file_type}</span>
      </div>
      <div className="info">
        <h3>{p.title}</h3>
        <p className="meta">โดย {p.shops?.name}</p>
        <span className="price">{baht(p.price_baht)}</span>
      </div>
    </Link>
  )
}
