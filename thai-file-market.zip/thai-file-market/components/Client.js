'use client'
import { useState } from 'react'
import { useRouter } from 'next/navigation'

export function Gallery({ images, title, ext }) {
  const [i, setI] = useState(0)
  if (!images.length) return <div className="big" style={{ background: '#0F5C63', color: '#fff' }}><span className="ext">{ext}</span></div>
  return (<div>
    <div className="big"><img src={images[i]} alt={`ตัวอย่าง ${title}`} /></div>
    <div className="ths">{images.map((s, k) => (
      <button key={k} className={`th ${k === i ? 'on' : ''}`} onClick={() => setI(k)} aria-label={`ภาพที่ ${k + 1}`}><img src={s} alt="" /></button>
    ))}</div>
  </div>)
}

export function BuyButton({ productId }) {
  const router = useRouter()
  const [busy, setBusy] = useState(false)
  const [err, setErr] = useState('')
  async function buy() {
    setBusy(true); setErr('')
    const r = await fetch('/api/checkout', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ productId }) })
    if (r.status === 401) return router.push('/login')
    if (!r.ok) { setErr('สั่งซื้อไม่สำเร็จ ลองใหม่อีกครั้ง'); setBusy(false); return }
    router.push('/orders')
  }
  return (<div><button className="btn" onClick={buy} disabled={busy}>ซื้อเลย</button>{err && <p className="err">{err}</p>}</div>)
}

export function MockPay({ orderId }) {
  const router = useRouter()
  async function pay() {
    await fetch('/api/pay', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ orderId }) })
    router.refresh()
  }
  return <button className="btn alt" onClick={pay}>จำลองการจ่ายเงิน (เฉพาะตอนพัฒนา)</button>
}
