'use client'
import { useState } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { createClient } from '@/lib/sb-browser'
import { CATEGORIES, FILE_TYPES } from '@/lib/const'

// ย่อภาพก่อนอัปโหลด (ด้านยาวสุด 1000px)
function toJpeg(file) {
  return new Promise((res, rej) => {
    const im = new Image()
    im.onload = () => {
      const k = Math.min(1, 1000 / Math.max(im.width, im.height))
      const c = document.createElement('canvas')
      c.width = Math.round(im.width * k); c.height = Math.round(im.height * k)
      c.getContext('2d').drawImage(im, 0, 0, c.width, c.height)
      c.toBlob((b) => (b ? res(b) : rej(new Error('แปลงภาพไม่สำเร็จ'))), 'image/jpeg', 0.85)
    }
    im.onerror = () => rej(new Error('เปิดไฟล์ภาพไม่ได้'))
    im.src = URL.createObjectURL(file)
  })
}

export default function Sell() {
  const sb = createClient()
  const router = useRouter()
  const [f, setF] = useState({ title: '', desc: '', cat: CATEGORIES[0], type: 'XLSX', price: '', shop: '' })
  const [images, setImages] = useState([])
  const [file, setFile] = useState(null)
  const [err, setErr] = useState('')
  const [busy, setBusy] = useState(false)
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value })

  async function publish(e) {
    e.preventDefault(); setErr('')
    if (!f.title.trim() || !(+f.price > 0)) return setErr('กรอกชื่อสินค้าและราคาให้ครบ')
    if (!images.length) return setErr('เพิ่มภาพตัวอย่างอย่างน้อย 1 ภาพ')
    if (!file) return setErr('เลือกไฟล์สินค้าที่ลูกค้าจะได้รับ')
    setBusy(true)
    try {
      const { data: { user } } = await sb.auth.getUser()
      if (!user) throw new Error('กรุณาเข้าสู่ระบบก่อน')
      let { data: shop } = await sb.from('shops').select('id').eq('owner_id', user.id).maybeSingle()
      if (!shop) {
        const r = await sb.from('shops').insert({ owner_id: user.id, name: f.shop.trim() || 'ร้านของฉัน' }).select('id').single()
        if (r.error) throw r.error
        shop = r.data
      }
      const { data: p, error } = await sb.from('products').insert({
        shop_id: shop.id, title: f.title.trim(), description: f.desc.trim(), category: f.cat, file_type: f.type, price_baht: +f.price,
      }).select('id').single()
      if (error) throw error
      try {
        for (let i = 0; i < images.length; i++) {
          const path = `${user.id}/${p.id}/${crypto.randomUUID()}.jpg`
          let r = await sb.storage.from('product-images').upload(path, await toJpeg(images[i]), { contentType: 'image/jpeg' })
          if (r.error) throw r.error
          r = await sb.from('product_images').insert({ product_id: p.id, path, position: i })
          if (r.error) throw r.error
        }
        const fpath = `${user.id}/${p.id}/${crypto.randomUUID()}` // ชื่อเป็นรหัส เก็บชื่อจริงในตาราง
        let r = await sb.storage.from('product-files').upload(fpath, file)
        if (r.error) throw r.error
        r = await sb.from('product_files').insert({ product_id: p.id, path: fpath, file_name: file.name, size_bytes: file.size })
        if (r.error) throw r.error
      } catch (e) {
        await sb.from('products').delete().eq('id', p.id)
        throw e
      }
      router.push(`/p/${p.id}`)
    } catch (e) {
      setErr(e.message || 'ลงขายไม่สำเร็จ')
    }
    setBusy(false)
  }

  return (
    <main className="wrap"><h1>ลงขายไฟล์ของคุณ</h1>
      <p className="note">ต้อง<Link href="/login"> เข้าสู่ระบบ </Link>ก่อนจึงจะลงขายได้</p>
      <form className="uf" onSubmit={publish}>
        <label>ชื่อสินค้า<input value={f.title} onChange={set('title')} maxLength={80} /></label>
        <div className="two">
          <label>หมวดหมู่<select value={f.cat} onChange={set('cat')}>{CATEGORIES.map((c) => <option key={c}>{c}</option>)}</select></label>
          <label>ประเภทไฟล์<select value={f.type} onChange={set('type')}>{FILE_TYPES.map((c) => <option key={c}>{c}</option>)}</select></label>
        </div>
        <div className="two">
          <label>ราคา (บาท)<input type="number" min="1" value={f.price} onChange={set('price')} /></label>
          <label>ชื่อร้าน (ใช้ครั้งแรกครั้งเดียว)<input value={f.shop} onChange={set('shop')} maxLength={40} /></label>
        </div>
        <label>รายละเอียด<textarea rows={4} maxLength={600} value={f.desc} onChange={set('desc')} /></label>
        <label>ภาพตัวอย่าง (สูงสุด 4 ภาพ ภาพแรกเป็นภาพปก)
          <input type="file" accept="image/*" multiple onChange={(e) => setImages([...e.target.files].slice(0, 4))} />
        </label>
        <label>ไฟล์สินค้าที่ลูกค้าจะได้รับ (ไม่เกิน 50 MB)
          <input type="file" onChange={(e) => setFile(e.target.files[0] || null)} />
        </label>
        {err && <p className="err" role="alert">{err}</p>}
        <button className="btn" disabled={busy}>{busy ? 'กำลังอัปโหลด...' : 'เผยแพร่สินค้า'}</button>
      </form>
    </main>
  )
}
