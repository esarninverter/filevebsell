import Link from 'next/link'
import Card from '@/components/Card'
import { CATEGORIES } from '@/lib/const'
import { createClient } from '@/lib/sb-server'

export default async function Home({ searchParams }) {
  const sp = await searchParams
  const q = (sp.q || '').replace(/[%_,()]/g, '').trim()
  const cat = sp.cat || ''
  const sb = await createClient()
  let query = sb.from('products')
    .select('id,title,price_baht,file_type,category,shops(name),product_images(path,position)')
    .order('created_at', { ascending: false })
  if (cat) query = query.eq('category', cat)
  if (q) query = query.ilike('title', `%${q}%`)
  const { data: products = [] } = await query
  return (
    <main className="wrap">
      <h1>ไฟล์ดิจิทัลฝีมือคนไทย โหลดได้ทันทีหลังจ่าย</h1>
      <form className="search" action="/">
        {cat && <input type="hidden" name="cat" value={cat} />}
        <input name="q" defaultValue={q} placeholder="ค้นหา เช่น ใบเสนอราคา, ฟอนต์" aria-label="ค้นหาไฟล์" />
        <button>ค้นหา</button>
      </form>
      <div className="chips">
        <Link href="/" className={`chip ${!cat ? 'on' : ''}`}>ทั้งหมด</Link>
        {CATEGORIES.map((c) => (
          <Link key={c} href={`/?cat=${encodeURIComponent(c)}`} className={`chip ${cat === c ? 'on' : ''}`}>{c}</Link>
        ))}
      </div>
      <p className="note">พบ {products.length} ไฟล์</p>
      <div className="grid">{products.map((p) => <Card key={p.id} p={p} />)}</div>
    </main>
  )
}
