import Link from 'next/link'
import { redirect } from 'next/navigation'
import { MockPay } from '@/components/Client'
import { baht } from '@/lib/const'
import { createClient } from '@/lib/sb-server'

export default async function Orders() {
  const sb = await createClient()
  const { data: { user } } = await sb.auth.getUser()
  if (!user) redirect('/login')
  const { data: orders = [] } = await sb.from('orders')
    .select('id,status,total_baht,created_at,order_items(price_baht,products(id,title))')
    .order('created_at', { ascending: false })
  return (
    <main className="wrap"><h1>ซื้อของฉัน</h1>
      {!orders.length && <p className="note">ยังไม่มีคำสั่งซื้อ <Link href="/">ไปเลือกไฟล์</Link></p>}
      {orders.map((o) => (
        <div className="box" key={o.id}>
          <p className="meta">{new Date(o.created_at).toLocaleString('th-TH')} · {o.status === 'paid' ? 'ชำระแล้ว' : 'รอชำระเงิน'} · {baht(o.total_baht)}</p>
          {o.order_items.map((i) => (
            <p key={i.products.id}>
              {i.products.title} {o.status === 'paid' && <a className="btn" href={`/api/download/${i.products.id}`}>ดาวน์โหลด</a>}
            </p>
          ))}
          {o.status === 'pending' && process.env.NODE_ENV !== 'production' && <MockPay orderId={o.id} />}
        </div>
      ))}
    </main>
  )
}
