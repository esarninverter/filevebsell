import { NextResponse } from 'next/server'
import { createClient } from '@/lib/sb-server'
// RLS คืนแถวไฟล์เฉพาะเจ้าของหรือผู้ซื้อที่จ่ายแล้ว จึงสร้างลิงก์ชั่วคราว 60 วินาทีได้เฉพาะคนเหล่านั้น
export async function GET(_req, { params }) {
  const { id } = await params
  const sb = await createClient()
  const { data: f } = await sb.from('product_files').select('path,file_name').eq('product_id', id).maybeSingle()
  if (!f) return new Response('ไม่มีสิทธิ์ดาวน์โหลดไฟล์นี้', { status: 403 })
  const { data, error } = await sb.storage.from('product-files').createSignedUrl(f.path, 60, { download: f.file_name })
  if (error) return new Response('สร้างลิงก์ดาวน์โหลดไม่สำเร็จ', { status: 500 })
  return NextResponse.redirect(data.signedUrl)
}
