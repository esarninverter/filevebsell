import { NextResponse } from 'next/server'
import { createClient as admin } from '@supabase/supabase-js'
import { createClient } from '@/lib/sb-server'

// 1) Webhook จากผู้ให้บริการชำระเงิน: ต้องส่ง header x-webhook-secret ให้ตรงกับ PAYMENT_WEBHOOK_SECRET
//    TODO ก่อนใช้งานจริง: ตรวจลายเซ็นของผู้ให้บริการ (Omise/2C2P ฯลฯ) และตรวจยอดเงินให้ตรงกับ orders.total_baht
// 2) โหมดจำลอง: ใช้ได้เฉพาะตอนไม่ใช่ production และเฉพาะออเดอร์ของผู้ใช้เอง
export async function POST(req) {
  const body = await req.json().catch(() => ({}))
  const secret = process.env.PAYMENT_WEBHOOK_SECRET
  const isHook = !!secret && req.headers.get('x-webhook-secret') === secret
  if (!isHook) {
    if (process.env.NODE_ENV === 'production') return NextResponse.json({ error: 'forbidden' }, { status: 403 })
    const sb = await createClient()
    const { data: o } = await sb.from('orders').select('id').eq('id', body.orderId).maybeSingle()
    if (!o) return NextResponse.json({ error: 'not found' }, { status: 404 })
  }
  const db = admin(process.env.NEXT_PUBLIC_SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY)
  const { error } = await db.from('orders')
    .update({ status: 'paid', paid_at: new Date().toISOString(), payment_ref: body.paymentRef || 'dev-mock' })
    .eq('id', body.orderId).eq('status', 'pending')
  if (error) return NextResponse.json({ error: error.message }, { status: 500 })
  return NextResponse.json({ ok: true })
}
