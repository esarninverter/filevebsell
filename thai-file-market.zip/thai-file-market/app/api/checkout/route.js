import { NextResponse } from 'next/server'
import { createClient } from '@/lib/sb-server'
// สร้างออเดอร์สถานะ pending ราคาในออเดอร์ถูกบังคับให้ตรงกับราคาสินค้าโดย RLS
export async function POST(req) {
  const { productId } = await req.json().catch(() => ({}))
  const sb = await createClient()
  const { data: { user } } = await sb.auth.getUser()
  if (!user) return NextResponse.json({ error: 'login required' }, { status: 401 })
  const { data: p } = await sb.from('products').select('id,price_baht').eq('id', productId).maybeSingle()
  if (!p) return NextResponse.json({ error: 'not found' }, { status: 404 })
  const { data: o, error } = await sb.from('orders').insert({ buyer_id: user.id }).select('id').single()
  if (error) return NextResponse.json({ error: error.message }, { status: 500 })
  const r = await sb.from('order_items').insert({ order_id: o.id, product_id: p.id, price_baht: p.price_baht })
  if (r.error) return NextResponse.json({ error: r.error.message }, { status: 500 })
  return NextResponse.json({ orderId: o.id })
}
