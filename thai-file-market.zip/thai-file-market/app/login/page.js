'use client'
import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { createClient } from '@/lib/sb-browser'

export default function Login() {
  const sb = createClient()
  const router = useRouter()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [msg, setMsg] = useState('')
  async function go(signUp) {
    setMsg('')
    const { data, error } = signUp
      ? await sb.auth.signUp({ email, password })
      : await sb.auth.signInWithPassword({ email, password })
    if (error) return setMsg(error.message)
    if (!data.session) return setMsg('ส่งอีเมลยืนยันแล้ว กรุณาเปิดลิงก์ในอีเมลก่อนเข้าสู่ระบบ')
    router.push('/'); router.refresh()
  }
  return (
    <main className="wrap"><h1>เข้าสู่ระบบ</h1>
      <div className="uf">
        <label>อีเมล<input type="email" value={email} onChange={(e) => setEmail(e.target.value)} autoComplete="email" /></label>
        <label>รหัสผ่าน (อย่างน้อย 6 ตัว)<input type="password" value={password} onChange={(e) => setPassword(e.target.value)} autoComplete="current-password" /></label>
        {msg && <p className="err" role="alert">{msg}</p>}
        <button className="btn" onClick={() => go(false)}>เข้าสู่ระบบ</button>
        <button className="btn alt" onClick={() => go(true)}>สมัครสมาชิก</button>
      </div>
    </main>
  )
}
