import './globals.css'
import Link from 'next/link'
import { Prompt, Noto_Sans_Thai } from 'next/font/google'
import { createClient } from '@/lib/sb-server'

const head = Prompt({ subsets: ['thai', 'latin'], weight: ['500', '700'], variable: '--head' })
const body = Noto_Sans_Thai({ subsets: ['thai', 'latin'], variable: '--body' })
export const metadata = { title: 'ไฟล์เด็ด ตลาดไฟล์ดิจิทัลไทย' }

export default async function Layout({ children }) {
  const sb = await createClient()
  const { data: { user } } = await sb.auth.getUser()
  return (
    <html lang="th" className={`${head.variable} ${body.variable}`}>
      <body>
        <header><div className="wrap bar">
          <Link href="/" className="logo"><span>ไฟล์</span>เด็ด</Link>
          <nav>
            {user ? (<>
              <Link href="/sell">ลงขายไฟล์</Link>
              <Link href="/orders">ซื้อของฉัน</Link>
              <form action="/auth/signout" method="post"><button>ออกจากระบบ</button></form>
            </>) : <Link href="/login">เข้าสู่ระบบ</Link>}
          </nav>
        </div></header>
        {children}
      </body>
    </html>
  )
}
