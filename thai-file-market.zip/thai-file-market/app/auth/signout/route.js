import { NextResponse } from 'next/server'
import { createClient } from '@/lib/sb-server'
export async function POST(req) {
  const sb = await createClient()
  await sb.auth.signOut()
  return NextResponse.redirect(new URL('/', req.url), { status: 303 })
}
