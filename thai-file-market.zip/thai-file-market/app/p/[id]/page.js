import { notFound } from 'next/navigation'
import { Gallery, BuyButton } from '@/components/Client'
import { baht, imgUrl } from '@/lib/const'
import { createClient } from '@/lib/sb-server'

export default async function Product({ params }) {
  const { id } = await params
  const sb = await createClient()
  const { data: p } = await sb.from('products')
    .select('id,title,description,category,file_type,price_baht,shops(name),product_images(path,position)')
    .eq('id', id).maybeSingle()
  if (!p) notFound()
  // RLS ส่งแถวนี้กลับมาเฉพาะเจ้าของสินค้าหรือผู้ที่จ่ายเงินแล้วเท่านั้น
  const { data: file } = await sb.from('product_files').select('file_name,size_bytes').eq('product_id', id).maybeSingle()
  const images = [...p.product_images].sort((a, b) => a.position - b.position).map((i) => imgUrl(i.path))
  return (
    <main className="wrap dg">
      <Gallery images={images} title={p.title} ext={p.file_type} />
      <div>
        <h1 style={{ fontSize: 28, marginTop: 0 }}>{p.title}</h1>
        <p className="meta">โดย {p.shops?.name} · {p.category} · {p.file_type}</p>
        <p className="price" style={{ fontSize: 30 }}>{baht(p.price_baht)}</p>
        <p className="desc">{p.description}</p>
        {file
          ? <a className="btn" href={`/api/download/${p.id}`}>ดาวน์โหลด {file.file_name}</a>
          : <BuyButton productId={p.id} />}
      </div>
    </main>
  )
}
