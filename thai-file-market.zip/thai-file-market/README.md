# ไฟล์เด็ด — ตลาดไฟล์ดิจิทัลไทย (Next.js + Supabase)

## เริ่มใช้งาน
1. `npm install`
2. คัดลอก `.env.example` เป็น `.env.local` แล้วใส่ `SUPABASE_SERVICE_ROLE_KEY` (Supabase Dashboard > Project Settings > API Keys) และตั้ง `PAYMENT_WEBHOOK_SECRET` เป็นสตริงสุ่มยาวๆ
3. `npm run dev` แล้วเปิด http://localhost:3000
4. สมัครสมาชิก > ลงขายไฟล์ > สมัครบัญชีที่สองเพื่อซื้อ > กด "จำลองการจ่ายเงิน" > ดาวน์โหลด

## ขึ้นออนไลน์ (Vercel)
นำโฟลเดอร์นี้ขึ้น GitHub > Import ที่ vercel.com > ใส่ตัวแปรสภาพแวดล้อมทั้ง 4 ตัว > Deploy
จากนั้นที่ Supabase > Authentication > URL Configuration ตั้ง Site URL เป็นโดเมนของคุณ

## สิ่งที่ยังต้องทำก่อนเปิดขายจริง
- ต่อผู้ให้บริการชำระเงิน (PromptPay QR ผ่าน Omise/2C2P ฯลฯ) ให้เรียก `POST /api/pay` พร้อม header `x-webhook-secret` และ **ตรวจลายเซ็น + ยอดเงิน** ในไฟล์ `app/api/pay/route.js` (มี TODO ไว้)
- ปุ่มจำลองการจ่ายเงินทำงานเฉพาะตอนที่ไม่ใช่ production
- ระบบโอนเงินให้ผู้ขาย ค่าคอมมิชชัน การตรวจเนื้อหา และการแจ้งลบงานละเมิดลิขสิทธิ์
- ยังไม่ได้รันทดสอบ build ในสภาพแวดล้อมของผม กรุณาลอง `npm run build` และแจ้งถ้าพบข้อผิดพลาด
- ถ้าอัปโหลดไฟล์ไม่สำเร็จกลางทาง ระบบลบสินค้าให้ แต่ไฟล์ที่อัปโหลดไปแล้วอาจค้างใน Storage

## ขึ้น Cloudflare Workers (OpenNext)
ใส่ค่า config ไว้ให้แล้ว (`wrangler.jsonc`, `open-next.config.ts`, สคริปต์ `deploy`)
1. `npm install` แล้ว `npx wrangler login`
2. ตั้งค่าลับ (ไม่ใส่ในไฟล์): `npx wrangler secret put SUPABASE_SERVICE_ROLE_KEY` และ `npx wrangler secret put PAYMENT_WEBHOOK_SECRET`
3. ค่า `NEXT_PUBLIC_*` ต้องมีตอน build: ใส่ใน `.env.local` ถ้า deploy จากเครื่อง หรือใส่ใน Build variables ถ้าใช้ Workers Builds
4. `npm run deploy` ได้ลิงก์ *.workers.dev
- Windows: OpenNext มีปัญหากับ Windows ให้ใช้ WSL หรือ deploy ผ่าน Workers Builds (เชื่อม GitHub) แทน
- หน้า preview ในเครื่องผ่าน Workers runtime ใช้ `npm run preview`
- Cloudflare แนะนำ vinext สำหรับโปรเจกต์ Next.js ใหม่ แต่ชุดนี้ใช้ OpenNext ซึ่งยังรองรับ Next.js 15
